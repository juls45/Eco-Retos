// Interacciones: completar reto sin recargar y mostrar mensajes
async function completarReto(retoId, btn) {
    btn.disabled = true;
    const resp = await fetch('/retos/complete', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({reto_id: retoId})
    });
    const data = await resp.json();
    if (data.success) {
        btn.innerText = 'Completado ✅';
        const puntosEl = document.getElementById('user-points');
        if (puntosEl) puntosEl.innerText = data.puntos;
    } else {
        alert(data.error || 'Error al completar el reto');
        btn.disabled = false;
    }
}
