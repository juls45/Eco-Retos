# Eco Retos - Proyecto mejorado

Este proyecto es una versión mejorada de la plataforma **Eco Retos**. Incluye:
- Backend en Flask con persistencia en SQLite.
- Registro e inicio de sesión de usuarios.
- Retos diarios almacenados en base de datos.
- Eco-calculadora con recomendaciones básicas.
- Dashboard con gráfico de puntos (Chart.js).
- Frontend estético con paleta de verdes.

## Ejecutar
1. Crear entorno virtual: `python -m venv venv`
2. Activar: `source venv/bin/activate` (Linux/Mac) o `venv\Scripts\activate` (Windows)
3. Instalar: `pip install -r requirements.txt`
4. Ejecutar: `python app.py`
5. Abrir: http://localhost:5000
